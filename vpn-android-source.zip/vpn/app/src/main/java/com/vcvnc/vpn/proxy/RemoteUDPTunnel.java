package com.vcvnc.vpn.proxy;


import com.vcvnc.vpn.Packet;
import com.vcvnc.vpn.ProxyConfig;
import com.vcvnc.vpn.VPNLog;
import com.vcvnc.vpn.service.FirewallVpnService;
import com.vcvnc.vpn.tcpip.IPHeader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;


public class RemoteUDPTunnel implements Runnable {
    private static final String TAG = RemoteUDPTunnel.class.getSimpleName();
    private final FirewallVpnService vpnService;
    private Socket socket;
    private InputStream is;
    private OutputStream os;
    private boolean isClose = true;

    private byte[] cacheBytes;
    private boolean haveCacheBytes = false;
    public static final int HEADER_SIZE = Packet.IP4_HEADER_SIZE + Packet.UDP_HEADER_SIZE;

    String ipAndPort;


    public RemoteUDPTunnel(FirewallVpnService vpnService) {
        this.vpnService = vpnService;

    }

    public void start() {
        initConnection();
        Thread thread = new Thread(this, "RemoteUDPTunnel");
        thread.start();
    }

    public boolean initConnection() {

        InetAddress destinationAddress = null;
        try {
            destinationAddress = InetAddress.getByName(ProxyConfig.serverIp);
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
        int destinationPort = ProxyConfig.serverPort;

        ipAndPort = destinationAddress.toString()+":"+ProxyConfig.serverPort;
        VPNLog.d(TAG, "init  ipAndPort:" + ipAndPort);

        try {
            socket =  new Socket(ProxyConfig.serverIp, destinationPort);
            is = socket.getInputStream();
            os = socket.getOutputStream();
            vpnService.protect(socket);
            isClose = false;

            byte[] header = new byte[Packet.IP4_HEADER_SIZE];
            IPHeader ipheader = new IPHeader(header, 0);
            ipheader.setHeaderLength(Packet.IP4_HEADER_SIZE);
            ipheader.setSourceIP(0);
            ipheader.setDestinationIP(0);
            ipheader.setProtocol(IPHeader.UDP);

            if(os != null) {
                os.write(header, 0, Packet.IP4_HEADER_SIZE);
            }else{
                this.vpnService.dispose();
            }


        } catch (IOException e) {
            System.out.println("------intit connect false: -------");
            this.vpnService.dispose();
            close();
            return false;
        }
        return true;
    }



    public void processPacket(Packet packet) {
        //System.out.println("------send server packet: -------"+packet);

        try {
            if(os != null) {
                os.write(packet.backingBuffer.array(), 0, packet.backingBuffer.array().length);
            }else{
                this.vpnService.dispose();
            }

        } catch (IOException e) {
            VPNLog.w(TAG, "Network write error: " + ipAndPort, e);
            //vpnServer.closeUDPConn(this);
            this.vpnService.dispose();
            close();
        }
    }

    public void close() {
        isClose = true;
        try {
            if (socket != null) {
                is.close();
                os.close();
                socket.close();
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    public boolean isClose() {
        if (socket == null)
            return true;
        return socket.isClosed() || isClose;
    }

    synchronized public void processRecvPacket(byte[] bytes, int size) throws UnknownHostException {

        if(this.haveCacheBytes) {
            byte[] data = new byte[this.cacheBytes.length + size];
            System.arraycopy(this.cacheBytes, 0, data, 0, this.cacheBytes.length);
            System.arraycopy(bytes, 0, data, this.cacheBytes.length, size);
            bytes = data;

            //System.out.println("#####recv size: "+size + " cache size: "+this.cacheBytes.length);
            size = this.cacheBytes.length + size;
            this.haveCacheBytes = false;

        }
        if (size < HEADER_SIZE) {
            byte[] data = new byte[size];
            System.arraycopy(bytes, 0, data, 0, size);
            this.cacheBytes = data;
            this.haveCacheBytes = true;
            //System.out.println("bad packet size, CacheBytes");
            return;
        }


        ByteBuffer byteBuffer = ByteBuffer.wrap(bytes, 0, size);
        byteBuffer.limit(size);
        Packet packet = new Packet(byteBuffer);

        //System.out.println("client recv size: "+size+"---------packet: "+packet);

        Packet.IP4Header Ip4Header = packet.getIp4Header();
        Packet.UDPHeader UDPHeader = packet.getUdpHeader();
        if (Ip4Header == null || UDPHeader == null) {
            System.out.println("#####process packet error: bad packet" );
            return;
        }

        if(size > packet.getIp4Header().totalLength){
            vpnService.write(bytes, 0, packet.getIp4Header().totalLength);
            int nextDataSize = size - packet.getIp4Header().totalLength;
            byte[] data = new byte[nextDataSize];
            System.arraycopy(bytes, packet.getIp4Header().totalLength, data, 0, nextDataSize);
            processRecvPacket(data, nextDataSize);
        }else if(size == packet.getIp4Header().totalLength){
            vpnService.write(bytes, 0, size);
        }else if(size < packet.getIp4Header().totalLength){
            byte[] data = new byte[size];
            System.arraycopy(bytes, 0, data, 0, size);

            this.cacheBytes = data;
            this.haveCacheBytes = true;
        }

    }

    @Override
    public void run() {
        try {
            int size = 0;
            byte[] bytes = new byte[ProxyConfig.MUTE];
            while (size != -1 && !isClose()) {
                size = is.read(bytes);

                if (size > 0) {
                    processRecvPacket(bytes, size);
                }
            }

        } catch (IOException e) {
            // TODO Auto-generated catch block
            // e.printStackTrace();
        } finally {
            close();
        }
    }

}
